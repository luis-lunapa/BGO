//
//  AppDelegate.swift
//  BGO
//
//  Created by Luis Luna on 09/02/17.
//  Copyright © 2017 X-Technologies & Consulting. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {
    let statusItem = NSStatusBar.system().statusItem(withLength: -2)
    var defaultWindow: NSWindow?
    
    
    
    
    
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
        
        if let button = statusItem.button {
            button.title = "Bubble Gum Overlay"
            button.appearsDisabled = false
            button.image = NSImage(named: "BGOMe")
            button.action = Selector("menuClick:")
            button.target = self
  
            
        
        }

        defaultWindow = NSApplication.shared().windows.first
        


           }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }
    
 @IBAction func menuClick(_ sender: AnyObject) {
    
    NSApplication.shared().windows.last!.makeKeyAndOrderFront(nil)
    NSApplication.shared().activate(ignoringOtherApps: true)
    print("Menu button pressed")
   
    
}
}

