//
//  ViewController.swift
//  BGO
//
//  Created by Luis Luna on 09/02/17.
//  Copyright © 2017 X-Technologies & Consulting. All rights reserved.
//

import Cocoa


class ViewController: NSViewController {

    @IBOutlet weak var gamesButton: NSButton!
    @IBOutlet weak var factsButton: NSButton!
    @IBOutlet weak var musicButton: NSButton!

    
    
    let gamesImg = NSImage(named: "games")! as NSImage
    let musicImg = NSImage(named: "music")! as NSImage
    let factsImg = NSImage(named: "facts")! as NSImage
    


    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewDidAppear() {
        super.viewDidAppear()
        self.view.window!.title = "Bubble Gum Overlay"
        gamesButton.image = gamesImg
        musicButton.image = musicImg
        factsButton.image = factsImg
  
    }
    

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
    
    @IBAction func factPressed(_ sender: Any) {
        print("FactsPressedddd")
    }
    @IBAction func factsPressed(_ sender: NSButton) {
        
        
        print("FactsPressed")
        
        
    }
    
    @IBAction func juegosPressed(_ sender: NSButton) {
        dialogAlert(text: "Juegos !")
    }
    
    @IBAction func musicaPressed(_ sender: NSButton) {
        dialogAlert(text: "Música !")
        
    }
    
    
    func dialogAlert(text: String) -> Bool{
       
        let title = "Hallo, Schön"
        let alert: NSAlert = NSAlert()
        alert.messageText = title
        alert.informativeText = text
        alert.alertStyle = NSAlertStyle.critical
        alert.addButton(withTitle: "OK")
        return alert.runModal() == NSAlertFirstButtonReturn
    }

   


}

