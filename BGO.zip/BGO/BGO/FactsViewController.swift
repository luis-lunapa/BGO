//
//  FactsViewController.swift
//  BGO
//
//  Created by Luis Luna on 15/02/17.
//  Copyright © 2017 X-Technologies & Consulting. All rights reserved.
//

import Cocoa

class FactsViewController: NSViewController {
    @IBOutlet weak var backButton: NSButton!
    @IBOutlet weak var nextButton: NSButton!
    
    let backImg = NSImage(named: "back")! as NSImage
    let nextImg = NSImage(named: "next")! as NSImage


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
  
    override func viewDidAppear() {
        super.viewDidAppear()
        self.view.window!.title = "¿Sabías qué, no sabías?"
     
        
 
        
        backButton.image = backImg
        nextButton.image = nextImg
        
        
        
    }
    
    
    override var representedObject: Any? {
        didSet {
            // Update the view, if already loaded.
        }
    }
    
}
